document.getElementById('year').textContent = new Date().getFullYear();
const contactForm = document.getElementById('contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!contactForm.reportValidity()) return;
    const name = contactForm.elements.name.value.trim();
    const phone = contactForm.elements.phone.value.trim();
    const type = contactForm.elements.type.value || 'استفسار عام';
    const message = contactForm.elements.message.value.trim();
    const subject = `طلب تواصل من الموقع — ${type}`;
    const body = `الاسم: ${name}\nرقم الجوال: ${phone}\nالخدمة: ${type}\n\nتفاصيل الطلب:\n${message}`;
    document.getElementById('form-status').textContent = 'تم تجهيز الرسالة. أكمل إرسالها من تطبيق البريد الذي سيفتح الآن. إذا لم يُفتح، استخدم البريد الظاهر أعلاه.';
    window.location.href = `mailto:info@sahmalmarafiq.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  });
}

const slides = Array.from(document.querySelectorAll('.showcase-slide'));
const slideButtons = Array.from(document.querySelectorAll('.slide-dot'));
if (slides.length && slideButtons.length === slides.length) {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const hero = document.querySelector('.showcase-hero');
  const count = document.querySelector('.slide-count');
  let current = 0;
  let timer;
  function showSlide(next) {
    current = (next + slides.length) % slides.length;
    slides.forEach((slide, index) => slide.classList.toggle('is-active', index === current));
    slideButtons.forEach((button, index) => {
      button.classList.toggle('is-active', index === current);
      button.setAttribute('aria-pressed', String(index === current));
    });
    count.textContent = `${String(current + 1).padStart(2, '0')} / ${String(slides.length).padStart(2, '0')}`;
  }
  function stop() { window.clearInterval(timer); timer = undefined; }
  function start() {
    stop();
    if (!reducedMotion.matches && !document.hidden) timer = window.setInterval(() => showSlide(current + 1), 6500);
  }
  slideButtons.forEach((button, index) => button.addEventListener('click', () => { showSlide(index); start(); }));
  hero.addEventListener('mouseenter', stop);
  hero.addEventListener('mouseleave', start);
  hero.addEventListener('focusin', stop);
  hero.addEventListener('focusout', start);
  document.addEventListener('visibilitychange', start);
  reducedMotion.addEventListener('change', start);
  start();
}
